# Pipeline Design

## Goal

Build a repeatable pipeline that turns local outdoor cat observations and public assumptions into advocacy-ready estimates.

## Pipeline Stages

1. Collect

   Inputs can include shelter intake, rescue kitten intake, TNR clinic records, community colony counts, 311 reports, foster waitlists, and public population estimates.

2. Normalize

   Convert local inputs into a shared schema:

   - `area`
   - `date`
   - `source_type`
   - `cat_count`
   - `female_share`
   - `intact_share`
   - `kitten_count`
   - `confidence`

3. Estimate

   Use adjustable assumptions to estimate:

   - daily outdoor kitten births
   - monthly kitten season pressure
   - sterilizations needed to bend the curve
   - foster capacity gap

4. Validate

   Compare estimates against observed kitten intake and local rescue reports. Flag places where the model is probably undercounting or overcounting.

5. Communicate

   Generate outputs for different audiences:

   - advocates: urgency and intervention points
   - shelters: capacity planning
   - local government: funding request
   - public: clear explanation and action steps

## Suggested Data Schema

```csv
area,date,source_type,cat_count,female_share,intact_share,kitten_count,confidence,notes
```

## Future Upgrade Ideas

- Add seasonal multipliers for kitten season.
- Add local weather and daylight factors.
- Connect to shelter intake dashboards.
- Create a public map of estimated outdoor births by county.
- Use Codex to draft grant language from the model output.

