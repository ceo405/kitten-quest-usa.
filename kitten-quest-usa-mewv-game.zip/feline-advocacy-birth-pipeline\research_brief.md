# Research Brief

## Core Question

How many cats are being born outside every day?

There is no single authoritative real-time count for outdoor cat births. The best responsible answer is a modeled estimate based on population size and reproduction assumptions.

## Key Assumptions

The included model uses this formula:

```text
daily outdoor kitten births =
outdoor cat population
* female share
* breeding-age female share
* intact breeding female share
* average litters per breeding female per year
* average kittens per litter
/ 365
```

## Included Scenarios

| Scenario | Outdoor cat population | Result |
| --- | ---: | ---: |
| Low | 25,000,000 | 55,377 births/day |
| Mid | 40,000,000 | 114,148 births/day |
| High | 60,000,000 | 217,479 births/day |

## Source Notes

- U.S. feral/free-roaming cat population estimates vary widely. Public summaries commonly cite ranges such as 25-60 million or 50-70 million. The model uses 25-60 million to avoid overstating certainty.
- A published free-ranging queen study summarized in public references reported 1-6 kittens per litter, an average of about 3 kittens, and about 1.4 litters per year, with a maximum of 3 litters in a year.
- Cat gestation is about 64-67 days, so multiple litters in a year are biologically possible.
- The model estimates births, not survival. Mortality before six months can be substantial for free-ranging kittens.

## Sources To Start From

- Domestic cat reproduction and feral population summary: https://en.wikipedia.org/wiki/Cat
- Feral cat definitions and U.S. population estimate discussion: https://en.wikipedia.org/wiki/Feral_cat
- Recent modeling example for free-ranging cat population dynamics: https://arxiv.org/abs/2412.14445

## Why A Range Matters

The advocacy risk is false precision. A single dramatic number can be memorable, but a transparent range is more credible. The project should invite people to adjust assumptions for their city, county, or rescue region.

## Meetup Demo Prompt

Ask Codex:

> Update the assumptions for Los Angeles County using a local outdoor cat population estimate, then explain how many kittens may be born outside each day and what interventions would reduce that number.
