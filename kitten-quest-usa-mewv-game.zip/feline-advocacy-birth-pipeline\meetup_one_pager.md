# Codex Community Meetup Project

## Kitten Quest USA by mewv.ai

This mewv.ai project uses Codex to investigate a deceptively simple question:

> How many cats are being born outside every day?

Instead of giving a single unsupported number, the project builds a transparent estimate from editable assumptions. It turns animal welfare advocacy into a data pipeline people can inspect, challenge, localize, and improve.

## Why It Matters

Outdoor kitten births drive shelter crowding, rescue overload, preventable suffering, and emergency foster demand. Advocates often know the crisis emotionally, but they need numbers that help them ask for funding, clinic access, policy support, and volunteer capacity.

## The Demo

Codex can:

- explain the assumptions in plain English
- rerun the model with local inputs
- generate a rescue-facing brief
- draft a city funding request
- create charts or a simple dashboard next

## Current Estimate

With national assumptions, the model estimates:

**55,000 to 217,000 kittens born outdoors per day in the United States.**

Midpoint:

**about 114,000 per day.**

## What Makes This A Good Codex Project

It combines research, data modeling, code, and human-centered communication. The project is small enough to understand in a meetup, but meaningful enough to become a real advocacy tool.

## Brand

Kitten Quest USA is a mewv.ai project. mewv.ai TM.
